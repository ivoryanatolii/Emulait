class HomePage:
    celebrating_beauty_header = "text=Celebrating Beauty and Style"
    celebrating_beauty_body = "text=playwright-practice was founded by a group of like-minded fashion devotees, dete"
